// Data Storage (using localStorage for persistence)
let rides = JSON.parse(localStorage.getItem('greenRideData')) || [];
let userRides = JSON.parse(localStorage.getItem('userRides')) || [];

// Route distance mapping (in km) - simplified for demo
const routeDistances = {
    'City Center-Main Campus': 8,
    'City Center-Engineering Block': 9,
    'City Center-Medical Campus': 12,
    'City Center-Business School': 10,
    'North Campus-Main Campus': 5,
    'North Campus-Engineering Block': 6,
    'South Residential-Main Campus': 7,
    'South Residential-Medical Campus': 6,
    'East Market-Engineering Block': 8,
    'West Industrial-Engineering Block': 10,
    'Railway Station-Main Campus': 15,
    'Railway Station-Business School': 14,
    'Airport Road-Main Campus': 20,
    'Tech Park-Engineering Block': 12
};

// CO2 emissions per km per person (in kg)
// Average car: 0.12 kg CO2/km per person
// When pooling, we divide by number of passengers
const CO2_PER_KM_SOLO = 0.12;

// Calculate CO2 savings
function calculateCO2Savings(route, passengers) {
    const distance = getRouteDistance(route);
    const soloCO2 = distance * CO2_PER_KM_SOLO * passengers;
    const pooledCO2 = distance * CO2_PER_KM_SOLO;
    const savings = soloCO2 - pooledCO2;
    return Math.round(savings * 10) / 10;
}

function getRouteDistance(route) {
    // Find exact or approximate match
    if (routeDistances[route]) {
        return routeDistances[route];
    }
    // Default to average distance if not found
    return 10;
}

// Screen Navigation
function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });
    document.getElementById(screenId).classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Set minimum date to today
function setMinDate() {
    const today = new Date().toISOString().split('T')[0];
    const dateInputs = ['offerDate', 'findDate'];
    dateInputs.forEach(id => {
        const input = document.getElementById(id);
        if (input) {
            input.setAttribute('min', today);
            input.value = today;
        }
    });
}

// Update potential savings when seats change
document.addEventListener('DOMContentLoaded', function() {
    setMinDate();
    updateCommunityImpact();
    
    const seatsSelect = document.getElementById('offerSeats');
    const startSelect = document.getElementById('offerStartLocation');
    const destSelect = document.getElementById('offerDestination');
    
    function updatePotentialSavings() {
        const seats = parseInt(seatsSelect.value) || 0;
        const start = startSelect.value;
        const dest = destSelect.value;
        
        if (seats > 0 && start && dest) {
            const route = `${start}-${dest}`;
            const savings = calculateCO2Savings(route, seats);
            document.getElementById('potentialSavings').textContent = `${savings} kg`;
        }
    }
    
    if (seatsSelect) {
        seatsSelect.addEventListener('change', updatePotentialSavings);
        startSelect.addEventListener('change', updatePotentialSavings);
        destSelect.addEventListener('change', updatePotentialSavings);
    }
});

// Offer Ride Form Submission
document.getElementById('offerRideForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const rideData = {
        id: Date.now(),
        type: 'offer',
        startLocation: document.getElementById('offerStartLocation').value,
        destination: document.getElementById('offerDestination').value,
        date: document.getElementById('offerDate').value,
        time: document.getElementById('offerTime').value,
        seats: parseInt(document.getElementById('offerSeats').value),
        vehicle: document.getElementById('offerVehicle').value,
        driverName: document.getElementById('offerName').value,
        driverContact: document.getElementById('offerContact').value,
        status: 'active',
        createdAt: new Date().toISOString()
    };
    
    // Calculate potential impact
    const route = `${rideData.startLocation}-${rideData.destination}`;
    const co2Savings = calculateCO2Savings(route, rideData.seats);
    rideData.potentialCO2Savings = co2Savings;
    
    // Save to storage
    rides.push(rideData);
    userRides.push(rideData);
    localStorage.setItem('greenRideData', JSON.stringify(rides));
    localStorage.setItem('userRides', JSON.stringify(userRides));
    
    // Show confirmation
    showConfirmation(rideData, 'offer');
    
    // Reset form
    this.reset();
    setMinDate();
});

// Find Ride Form Submission
document.getElementById('findRideForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const searchCriteria = {
        startLocation: document.getElementById('findStartLocation').value,
        destination: document.getElementById('findDestination').value,
        date: document.getElementById('findDate').value,
        time: document.getElementById('findTime').value,
        passengerName: document.getElementById('findName').value,
        passengerContact: document.getElementById('findContact').value
    };
    
    // Find matching rides
    const matches = findMatchingRides(searchCriteria);
    
    // Display matches
    displayRideMatches(matches, searchCriteria);
});

function findMatchingRides(criteria) {
    const searchTime = new Date(`${criteria.date}T${criteria.time}`);
    const timeWindow = 30 * 60 * 1000; // 30 minutes window
    
    return rides.filter(ride => {
        if (ride.status !== 'active' || ride.seats <= 0) return false;
        
        const rideTime = new Date(`${ride.date}T${ride.time}`);
        const timeDiff = Math.abs(searchTime - rideTime);
        
        // Match criteria:
        // 1. Same start and destination
        // 2. Same date
        // 3. Within 30 minute time window
        return ride.startLocation === criteria.startLocation &&
               ride.destination === criteria.destination &&
               ride.date === criteria.date &&
               timeDiff <= timeWindow;
    });
}

function displayRideMatches(matches, searchCriteria) {
    const container = document.getElementById('rideMatchesContainer');
    const subtitle = document.getElementById('matchesSubtitle');
    
    if (matches.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">🔍</div>
                <h3>No rides found</h3>
                <p>We couldn't find any rides matching your route and time. Try adjusting your search or check back later!</p>
                <button class="btn btn-primary" onclick="showScreen('offerRideScreen')">
                    Offer a ride instead
                </button>
            </div>
        `;
    } else {
        subtitle.textContent = `Found ${matches.length} ride${matches.length > 1 ? 's' : ''} matching your route`;
        
        container.innerHTML = matches.map(ride => `
            <div class="ride-card">
                <div class="ride-header">
                    <div class="ride-route">
                        <div class="route-display">
                            <span>${ride.startLocation}</span>
                            <span class="route-arrow">→</span>
                            <span>${ride.destination}</span>
                        </div>
                    </div>
                    <div class="ride-timing">
                        <div class="ride-date">${formatDate(ride.date)}</div>
                        <div class="ride-time">${formatTime(ride.time)}</div>
                    </div>
                </div>
                
                <div class="ride-details">
                    <div class="detail-item">
                        <span class="detail-icon">🪑</span>
                        <div class="detail-text">
                            <span class="detail-label">Seats Available</span>
                            <span class="detail-value">${ride.seats}</span>
                        </div>
                    </div>
                    <div class="detail-item">
                        <span class="detail-icon">🚗</span>
                        <div class="detail-text">
                            <span class="detail-label">Vehicle</span>
                            <span class="detail-value">${ride.vehicle}</span>
                        </div>
                    </div>
                    <div class="detail-item">
                        <span class="detail-icon">📏</span>
                        <div class="detail-text">
                            <span class="detail-label">Distance</span>
                            <span class="detail-value">${getRouteDistance(`${ride.startLocation}-${ride.destination}`)} km</span>
                        </div>
                    </div>
                </div>
                
                <div class="impact-badge-card">
                    <div class="impact-badge-content">
                        <div class="impact-badge-icon">🌱</div>
                        <div class="impact-badge-text">
                            <h4>Environmental Impact</h4>
                            <p>${ride.potentialCO2Savings} kg CO₂ saved</p>
                        </div>
                    </div>
                    <div class="impact-comparison">
                        ≈ ${Math.round(ride.potentialCO2Savings / 0.06)} km<br>of trees absorbing CO₂
                    </div>
                </div>
                
                <div class="contact-section">
                    <div class="driver-info">
                        <div class="driver-avatar">${ride.driverName.charAt(0).toUpperCase()}</div>
                        <div class="driver-details">
                            <h4>${ride.driverName}</h4>
                            <p>Driver • ${ride.vehicle}</p>
                        </div>
                    </div>
                    <button class="contact-btn" onclick="contactDriver('${ride.driverContact}', '${ride.driverName}')">
                        📞 Contact Driver
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    showScreen('rideMatchesScreen');
}

function contactDriver(contact, name) {
    alert(`Contact ${name} at: ${contact}\n\nYou can call or message them to confirm the ride details.`);
}

function showConfirmation(rideData, type) {
    const title = document.getElementById('confirmationTitle');
    const message = document.getElementById('confirmationMessage');
    const impactSummary = document.getElementById('impactSummary');
    
    if (type === 'offer') {
        title.textContent = 'Ride Offer Published! 🎉';
        message.textContent = 'Your ride has been added to the system. Riders will be able to see and contact you.';
        
        const distance = getRouteDistance(`${rideData.startLocation}-${rideData.destination}`);
        const treesEquivalent = Math.round(rideData.potentialCO2Savings / 0.06);
        
        impactSummary.innerHTML = `
            <h3>🌍 Your Environmental Impact</h3>
            <div class="impact-details">
                <div class="impact-item">
                    <div class="impact-item-icon">🌱</div>
                    <div class="impact-item-value">${rideData.potentialCO2Savings} kg</div>
                    <div class="impact-item-label">CO₂ Potentially Saved</div>
                </div>
                <div class="impact-item">
                    <div class="impact-item-icon">🌳</div>
                    <div class="impact-item-value">${treesEquivalent}</div>
                    <div class="impact-item-label">Trees Equivalent</div>
                </div>
                <div class="impact-item">
                    <div class="impact-item-icon">📏</div>
                    <div class="impact-item-value">${distance} km</div>
                    <div class="impact-item-label">Route Distance</div>
                </div>
                <div class="impact-item">
                    <div class="impact-item-icon">👥</div>
                    <div class="impact-item-value">${rideData.seats}</div>
                    <div class="impact-item-label">Seats Offered</div>
                </div>
            </div>
            <p style="margin-top: 20px; color: var(--text-secondary);">
                If all seats are filled, you'll prevent <strong>${rideData.potentialCO2Savings} kg of CO₂</strong> from entering the atmosphere!
                That's equivalent to the carbon absorbed by <strong>${treesEquivalent} trees</strong> in a day.
            </p>
        `;
    }
    
    showScreen('confirmationScreen');
    updateCommunityImpact();
}

function updateCommunityImpact() {
    const totalCO2 = rides.reduce((sum, ride) => {
        return sum + (ride.potentialCO2Savings || 0);
    }, 0);
    
    // Simulate daily community impact (would come from backend in real app)
    const dailyImpact = Math.round(totalCO2 * 1.5);
    document.getElementById('communityImpact').textContent = `${dailyImpact} kg CO₂`;
}

function viewMyRides() {
    displayMyRides();
    showScreen('myRidesScreen');
}

function displayMyRides() {
    const container = document.getElementById('myRidesContainer');
    const myActiveRides = userRides.filter(r => r.status === 'active');
    
    // Calculate user's total impact
    const totalCO2 = userRides.reduce((sum, ride) => sum + (ride.potentialCO2Savings || 0), 0);
    const totalRides = userRides.length;
    const treesEquivalent = Math.round(totalCO2 / 0.06);
    
    document.getElementById('myTotalCO2').textContent = `${Math.round(totalCO2)} kg`;
    document.getElementById('myTotalRides').textContent = totalRides;
    document.getElementById('myTotalTrees').textContent = treesEquivalent;
    
    if (myActiveRides.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">🚗</div>
                <h3>No active rides yet</h3>
                <p>Start by offering a ride or booking one to see your environmental impact!</p>
                <div class="button-group">
                    <button class="btn btn-primary" onclick="showScreen('offerRideScreen')">
                        Offer a Ride
                    </button>
                    <button class="btn btn-secondary" onclick="showScreen('findRideScreen')">
                        Find a Ride
                    </button>
                </div>
            </div>
        `;
    } else {
        container.innerHTML = myActiveRides.map(ride => `
            <div class="ride-card">
                <div class="ride-header">
                    <div class="ride-route">
                        <div class="route-display">
                            <span>${ride.startLocation}</span>
                            <span class="route-arrow">→</span>
                            <span>${ride.destination}</span>
                        </div>
                    </div>
                    <div class="ride-timing">
                        <div class="ride-date">${formatDate(ride.date)}</div>
                        <div class="ride-time">${formatTime(ride.time)}</div>
                    </div>
                </div>
                
                <div class="ride-details">
                    <div class="detail-item">
                        <span class="detail-icon">🪑</span>
                        <div class="detail-text">
                            <span class="detail-label">Seats</span>
                            <span class="detail-value">${ride.seats}</span>
                        </div>
                    </div>
                    <div class="detail-item">
                        <span class="detail-icon">🚗</span>
                        <div class="detail-text">
                            <span class="detail-label">Vehicle</span>
                            <span class="detail-value">${ride.vehicle}</span>
                        </div>
                    </div>
                    <div class="detail-item">
                        <span class="detail-icon">📞</span>
                        <div class="detail-text">
                            <span class="detail-label">Contact</span>
                            <span class="detail-value">${ride.driverContact}</span>
                        </div>
                    </div>
                </div>
                
                <div class="impact-badge-card">
                    <div class="impact-badge-content">
                        <div class="impact-badge-icon">🌱</div>
                        <div class="impact-badge-text">
                            <h4>Your Impact</h4>
                            <p>${ride.potentialCO2Savings} kg CO₂ saved</p>
                        </div>
                    </div>
                </div>
                
                <div class="button-group" style="margin-top: 20px;">
                    <button class="btn btn-secondary" onclick="cancelRide(${ride.id})">
                        Cancel Ride
                    </button>
                </div>
            </div>
        `).join('');
    }
}

function cancelRide(rideId) {
    if (confirm('Are you sure you want to cancel this ride?')) {
        // Update status in both arrays
        rides = rides.map(r => r.id === rideId ? {...r, status: 'cancelled'} : r);
        userRides = userRides.map(r => r.id === rideId ? {...r, status: 'cancelled'} : r);
        
        // Save to storage
        localStorage.setItem('greenRideData', JSON.stringify(rides));
        localStorage.setItem('userRides', JSON.stringify(userRides));
        
        // Refresh display
        displayMyRides();
        updateCommunityImpact();
        
        alert('Ride cancelled successfully.');
    }
}

// Utility Functions
function formatDate(dateStr) {
    const date = new Date(dateStr);
    const options = { weekday: 'short', month: 'short', day: 'numeric' };
    return date.toLocaleDateString('en-US', options);
}

function formatTime(timeStr) {
    const [hours, minutes] = timeStr.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
}

// Add some demo data on first load
if (rides.length === 0) {
    const demoRides = [
        {
            id: Date.now() - 1000,
            type: 'offer',
            startLocation: 'City Center',
            destination: 'Main Campus',
            date: new Date().toISOString().split('T')[0],
            time: '08:30',
            seats: 2,
            vehicle: 'Sedan',
            driverName: 'Priya Sharma',
            driverContact: '9876543210',
            status: 'active',
            potentialCO2Savings: calculateCO2Savings('City Center-Main Campus', 2),
            createdAt: new Date().toISOString()
        },
        {
            id: Date.now() - 2000,
            type: 'offer',
            startLocation: 'Railway Station',
            destination: 'Engineering Block',
            date: new Date().toISOString().split('T')[0],
            time: '09:00',
            seats: 3,
            vehicle: 'SUV',
            driverName: 'Rahul Kumar',
            driverContact: '9876543211',
            status: 'active',
            potentialCO2Savings: calculateCO2Savings('Railway Station-Engineering Block', 3),
            createdAt: new Date().toISOString()
        }
    ];
    
    rides = demoRides;
    localStorage.setItem('greenRideData', JSON.stringify(rides));
    updateCommunityImpact();
}

// Console message
console.log('%c🌍 GreenRide - Sustainable Transport Pooling', 'font-size: 16px; font-weight: bold; color: #4CAF50;');
console.log('%cEvery shared ride makes a difference!', 'font-size: 14px; color: #66BB6A;');
console.log(`%cCurrent rides in system: ${rides.length}`, 'font-size: 12px;');
console.log(`%cTotal CO₂ savings potential: ${Math.round(rides.reduce((sum, r) => sum + (r.potentialCO2Savings || 0), 0))} kg`, 'font-size: 12px; font-weight: bold; color: #4CAF50;');
